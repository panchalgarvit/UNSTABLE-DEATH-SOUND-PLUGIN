package com.example.deatheffects;

import org.bukkit.plugin.java.JavaPlugin;

public final class DeathEffectsPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(new DeathListener(this), this);
        getLogger().info("DeathEffects enabled.");
    }
}
