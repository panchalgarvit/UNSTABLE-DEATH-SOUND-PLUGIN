package com.example.deatheffects;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound.Source;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public final class DeathListener implements Listener {

    private final DeathEffectsPlugin plugin;

    public DeathListener(DeathEffectsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        FileConfiguration config = plugin.getConfig();
        Player player = event.getEntity();
        Location loc = player.getLocation();
        World world = loc.getWorld();
        if (world == null) {
            return;
        }

        playDeathSound(player, loc, config);

        if (config.getBoolean("lightning.enabled", true)) {
            // strikeLightningEffect is purely visual/audio - no damage, no fire, no block changes
            world.strikeLightningEffect(loc);
        }
    }

    private void playDeathSound(Player deadPlayer, Location loc, FileConfiguration config) {
        String soundName = config.getString("sound.name", "ENTITY_WITHER_SPAWN");
        boolean custom = config.getBoolean("sound.custom", false);
        float volume = (float) config.getDouble("sound.volume", 1.0);
        float pitch = (float) config.getDouble("sound.pitch", 1.0);
        double radius = config.getDouble("sound.radius", 450);

        World world = loc.getWorld();
        if (world == null) {
            return;
        }

        for (Player nearby : world.getPlayers()) {
            if (radius >= 0 && nearby.getLocation().distanceSquared(loc) > radius * radius) {
                continue;
            }
            if (custom) {
                nearby.playSound(net.kyori.adventure.sound.Sound.sound(
                        Key.key(soundName),
                        Source.PLAYER,
                        volume,
                        pitch
                ), loc.getX(), loc.getY(), loc.getZ());
            } else {
                try {
                    Sound bukkitSound = Sound.valueOf(soundName.toUpperCase());
                    nearby.playSound(loc, bukkitSound, volume, pitch);
                } catch (IllegalArgumentException ex) {
                    plugin.getLogger().warning("Unknown sound '" + soundName
                            + "' in config.yml - check https://jd.papermc.io/paper/26.1.2/org/bukkit/Sound.html"
                            + " or set sound.custom: true for resource-pack sounds.");
                }
            }
        }
    }
}
